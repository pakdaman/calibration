glmgen
======

Generalized lasso implementations. To install the
R library directly from github, run the following from R:

```{r}
 library(devtools)
 install_github("statsmaths/glmgen", subdir="R_pkg/glmgen")
```

See the C documentation published at [c docs](http://statsmaths.github.io/glmgen/html/files.html),
and the R documentation published at [R docs](http://statsmaths.github.io/glmgen/glmgen-manual.pdf).

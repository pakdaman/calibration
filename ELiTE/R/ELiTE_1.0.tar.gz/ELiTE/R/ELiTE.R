require('glmgen')

getAUC = function(Actual,Predicted){
  stopifnot( (length(unique(Actual))==2)&(max(unique(Actual))==1))
  nTarget     = sum(Actual == 1);
  nBackground = sum(Actual != 1);
  # Rank data
  R = rank(Predicted, ties.method = "average");  # % 'tiedrank' from Statistics Toolbox  
  #   Calculate AUC
  AUC = (sum(R[Actual == 1]) - (nTarget^2 + nTarget)/2) / (nTarget * nBackground);
  AUC = max(AUC,1-AUC);
  return(AUC)
}

getMCE = function ( Y, P ){
  predictions = P;
  labels = Y;
  sortObj = sort.int(predictions, index.return=TRUE)
  predictions = sortObj$x
  labels = labels[sortObj$ix]
  ordered = cbind(predictions,labels)
  N = length(predictions);
  rest = N%%10;
  S=rep(0,10)
  for (i in 1:10){
    if (i <= rest){
      startIdx = as.integer((i-1) * ceiling(N / 10) + 1)
      endIdx = as.integer(i * ceiling(N / 10))
    }else{
      startIdx = as.integer(rest + (i-1)*floor(N/10)+1)
      endIdx = as.integer(rest + i*floor(N/10))    
    }
    group = ordered[startIdx:endIdx,];
    
    n = dim(group)[1];
    observed = mean(group[,2]);
    expected = mean(group[,1]);
    S[i] = abs(expected-observed);
  }
  res = max(S);
  return(res)
}

getECE = function ( Y, P ){
  predictions = P;
  labels = Y;
  sortObj = sort.int(predictions, index.return=TRUE)
  predictions = sortObj$x
  labels = labels[sortObj$ix]
  ordered = cbind(predictions,labels)
  N = length(predictions);
  rest = N%%10;
  S=rep(0,10)
  W=rep(0,10)
  for (i in 1:10){
    if (i <= rest){
      startIdx = as.integer((i-1) * ceiling(N / 10) + 1)
      endIdx = as.integer(i * ceiling(N / 10))
    }else{
      startIdx = as.integer(rest + (i-1)*floor(N/10)+1)
      endIdx = as.integer(rest + i*floor(N/10))    
    }
    group = ordered[startIdx:endIdx,];
    
    n = dim(group)[1];
    observed = mean(group[,2]);
    expected = mean(group[,1]);
    S[i] = abs(expected-observed);
    W[i] = n/N;
  }
  res = sum(S*W);
  return(res)
}

getRMSE = function( Y, P ){
  res = sqrt(sum((Y-P)*(Y-P))/length(Y));
}

get_score_local = function(z_org, p_org, w, df, option, bname) {
  # Returns the score
  # to make sure that everything is in [0,1], so it is valid probability
  idx = p_org > 1
  p_org[idx] = 1
  idx = p_org < 0
  p_org[idx] = 0
  
  #   N = sum(w); # Total number of training instances
  
  # First compute loglikelihood of unique instances
  idx = (w==1)
  z = z_org[idx]
  p = p_org[idx]
  l = p;
  idx = (z==0);
  l[idx] = 1-p[idx];
  
  # Removing the zeros
  idx = (l!=0) 
  l = l[idx] 
  N = length(l)
  #-------------------
  
  logLikelihood = sum(log(l));
  
  # Second add the loglikelihood component of the instances that are not unique
  idx = (w>1);
  z = z_org[idx]
  p = p_org[idx]
  w_idx = w[idx] 
  if (length(z)>=1){
    for (i in 1:length(z)){
      if (z[i]==1 && p[i]!=0){
        N = N + 1
        logLikelihood = logLikelihood + log(p[i])*(w_idx[i]);
      }else if (z[i] == 0 &&  p[i]!= 1){
        N = N + 1
        logLikelihood = logLikelihood + log(1-p[i])*(w_idx[i]);
      }else if(p[i]!=0 && p[i]!=1) {
        N = N + 1
        logLikelihood = logLikelihood + log(p[i])*(w_idx[i]*z[i]) +log(1-p[i])*(w_idx[i]*(1-z[i]));
      }
    }
  }
  
  
  if (option == 'AICc'){
    score = 2*df - 2*logLikelihood + 2*df*(df+1)/(N-df-1);
  } else if (option == 'BIC'){
    score = -2*logLikelihood + df *(log(N)+log(2*pi));
    #        score = -2*logLikelihood + df *log(N);
  } else if (option == 'AIC'){
    score = 2*df -2*logLikelihood;
  } else {
    error('We only support AIC, AICc, or BIC')
  }
}

thinningLocal = function (y_in, z_in){
  N = length(z_in);
  binWidth = 10^-5;
  bin_idx = ceiling(y_in/binWidth);
  y_out_l = rep(0, N);
  z_out_l = rep(0, N);
  w_out_l = rep(0, N);
  out_idx = 0;
  i = 1;
  while (i <= N){
    p_ij = y_in[i];
    y_ij = z_in[i];
    j = i + 1;
    while (j <= N && bin_idx[j] == bin_idx[i]){ 
      p_ij = p_ij+ y_in[j];
      y_ij = y_ij + z_in[j];
      j = j+1;
    }
    n_ij = j-i;
    out_idx = out_idx + 1;
    y_out_l[out_idx] =  p_ij/n_ij;
    z_out_l[out_idx] = y_ij/n_ij;
    w_out_l[out_idx] = n_ij;
    i = j;
  }
  res = list();
  res$y = y_out_l[1:out_idx];
  res$z = z_out_l[1:out_idx];
  res$w = w_out_l[1:out_idx];
#   assert(sum(w_out)==N,'error: sum of all w_out must be equal to N!');
  stopifnot(sum(res$w)==N)
  return(res);
}



#'@title Computer evaluation measures for binary classification scores
#'@author Mahdi Pakdaman
#'@param PTE: vector predicted of classification scores, YTE: corresponding true class \{0,1\}
#'@export
elite.getMeasures = function(PTE, YTE ){
  #   GETMEASURES Summary of this function goes here
  if (sum(!is.finite(PTE))>0){
    print('there are some nan value in predictions')
  }
  
  if (sum(!is.finite(YTE))>0){
    print('there are some nan value in predictions')
  }
  
  
  idx = is.finite(YTE)&is.finite(PTE);
  YTE = YTE[idx]; PTE = PTE[idx];
  
  res = list();
  res$RMSE = getRMSE(YTE,PTE);
  res$AUC = getAUC(YTE,PTE);
  res$ACC = sum(YTE==(PTE>=0.5))/length(YTE);    
  res$MCE = getMCE(YTE,PTE); #Computing the Max Calibratio Error among all bins 
  res$ECE = getECE(YTE,PTE); #Computing Average Calinration Error on different binns
  return(res)
}

#'@title Create ELiTE model
#'@author Mahdi Pakdaman
#'@param y: uncalibrated classification scores y [0,1], z: corresponding true class z \{0,1\}
#'@export
elite.build = function(y, z, scoreFunc='AICc', K = 1, thining = 1){
  #Extract the degree of polynomial k  
  #Setting the combination measure (BIC, AIC, AICc) 
  measure = scoreFunc
  
  if (thining==1){
    res = thinningLocal(y, z);
    y = res$y
    z = res$z
    w = res$w
  }else{
    w = ones(length(z),1);
  }
  
  # Calling trend filter module
  model = glmgen::trendfilter(y, z, weights = w, k=K, method = c("admm"), lambda.min.ratio = 1e-04)
  # , family = "logistic"
  # , family = "gaussian"
  
  lambda =  model$lambda
  beta = model$beta
  df = model$df
 
  MNM = length(df); # Maximum Number of Models
  scores = rep(0,MNM)
  for (i in 1:MNM){
    p = model$beta[,i]
    df = model$df[i]
    scores[i] = get_score_local(model$y, p, model$weights, df, measure, bname)    
    # Computing the score based on all original train data
    #   lambda_i = model$lambda[i]
    #   p = predict(model,x.new=y,lambda=lambda_i)
    #   scores[i] = get_score_local(y, p, df, 'BIC')
  }
  
  maxScore = -Inf
  maxScoreIdx = 0
  minScore = Inf
  minScoreIdx = 0
  SV = rep(0,MNM)
  for (b in 1:MNM){
    SV[b] = scores[b]
    if (scores[b] > maxScore){
      maxScoreIdx = b
      maxScore = scores[b]
    }
    
    if (scores[b] < minScore){
      minScoreIdx = b;
      minScore = scores[b];
    }
  }
  if (min(SV)==max(SV)){
    SV = rep(1,MNM)/MNM
  }else{
    SV = exp((min(SV)-SV)/2); # Compute Reletive Likelihood
    SV = SV/sum(SV) # Normalize the scores  
  }
  
  model$maxScoreIdx = maxScoreIdx; # Will be used for Model selection
  model$minScoreIdx = minScoreIdx; # Will be used for Model selection
  model$SV = SV
  
  return(model);
}

#'@title predict calibrated estimate for an uncalibrated score using previously built ENIR model
#'@author Mahdi Pakdaman
#'@param y: uncalibrated classification scores y [0,1], z: corresponding true class z \{0,1\}
#'@export
elite.predict = function( model, pin, option = 1 ){
  #   This function used for calibrating the probabilitiesusing ENIR model
  #   Input: 
  #          - elite: the elite model learnt by elite.build
  #          - pin : vector of Uncalibrated probabilities
  #          - option: 0 use model selection, 1 use model Averaging   
  #    Output:
  #            - out : vector of calibrated probabilities
  y <- pin
  m = length(model$df)
  out = rep(0,length(y))
  for (i in 1:m){
    lambda_i = model$lambda[i]
    p = predict(model,x.new=y,lambda=lambda_i)
    # to make sure that everything is in [0,1], so it is valid probability
    idx = p > 1
    p[idx] = 1
    idx = p < 0
    p[idx] = 0
    
    out = out + p*model$SV[i]
  }
  return(out);
}

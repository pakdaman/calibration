# # install.packages("e1071", dependencies = TRUE)
# # install.packages("R.matlab", dependencies = TRUE)
# setwd('/Users/mahdi/Research/Calibration/Thesis/Code/R_Matlab/')
# library(R.matlab)
# library(e1071)
# 
# 
# data = readMat("data.mat")
# XTrain = data$XTR
# XTest = data$XTE
# 
# ztr = data$YTR
# zte = data$YTE
# 
# svm.model = e1071::svm(XTrain, ztr, decision.values = TRUE)
# summary(svm.model)
# ytr = stats::predict(svm.model, XTrain)
# yte = stats::predict(svm.model, XTest)







# setwd('/Users/mahdi/Research/Calibration/Thesis/Code/R_Matlab/')
# zname = 'train_data_z.csv'
# yname = 'train_data_y.csv'
# tmp <- read.csv(yname, header=FALSE)
# ytr <- tmp$V1
# tmp <- read.csv(zname, header=FALSE)
# ztr <- tmp$V1
# 
# zname = 'test_data_z.csv'
# yname = 'test_data_y.csv'
# tmp <- read.csv(yname, header=FALSE)
# yte <- tmp$V1
# tmp <- read.csv(zname, header=FALSE)
# zte <- tmp$V1
# 
# library(enir)
# 
# Mobj =getMeasures(yte,zte)
# model = build(ytr, ztr, 'BIC')
# PTE_enir = predict(model, yte, 1);
# Mobj_calibrated =getMeasures(PTE_enir,zte)